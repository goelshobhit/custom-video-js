import './App.css';
import 'antd/dist/antd.css';
import VideoPlayer from './VIdeoPlayer';

function App() {
  return (
    <div className="App">
     <VideoPlayer />
    </div>
  );
}

export default App;
